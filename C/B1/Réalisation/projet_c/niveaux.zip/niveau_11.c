#include <stdio.h>
#include <stdlib.h>

int niveau11 (){

    char tableau_niveau_11[4][5] = {{ 'x', 1,  1,  1},
                                    {  1, 'x', 1,  1},
                                    {  1,  1, 'x', 1},
                                    {  1,  1,  1,  1},
                                    {  1,  1,  1,  1}};

    printf(tableau_niveau_11);
    return 0;
}

