insert into AVION (NUMERO_ENREGISTREMENT,CAPACITE)
values  

#Avion pour l'Eurore:		
        ("EP01",   400),
		("EP02",   200),
        ("EP03",   300),
        ("EP04",   800),
        ("EP05",   250),

#Avion pour l'Amérique Latine:       
        ("AML01", 930),
		("AML02", 460),
        ("AML03", 710),
        ("AML04", 320),
        ("AML05", 530),
        
#Avion pour l'Afrique:

        ("AF01",  500),
        ("AF02",  800),
        ("AF03",  700),
        ("AF04",  110),
        ("AF05",  342),
     
#Avion pour l'Asie: 
        
        ("AS01",  935),
        ("AS02",  850),
        ("AS13",  705),
        ("AS04",  500),
        ("AS05",  670);
        