#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <tchar.h>
#include <string.h>
#include <conio.h>
#include <unistd.h>
#include <windows.h>

char tableau_niveau_1[3] = {'x', '1', '1'};
char printGrille1(char tableau_niveau_1[3]){
    for ( int i = 0; i < sizeof(tableau_niveau_1); i++) {
    printf("%c \t", tableau_niveau_1[i]);
    }
    printf("\n");

    return 0;
    }
