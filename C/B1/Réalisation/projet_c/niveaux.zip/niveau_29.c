#include <stdio.h>
#include <stdlib.h>

int niveau29 (){

    char tableau_niveau_29[6][5] = {{ 1,   1,   1,   'x',    1,   'x'},
                                    {'.',  1,   1,    1,     1,   '.'},
                                    { 1,   1,   1,   'x',    1,    1 },
                                    {'.', 'x',  1,   'x',    1,   '.'},
                                    { 1,   1,   1,    1,     1,    1}};

    printf(tableau_niveau_29);
    return 0;
}

