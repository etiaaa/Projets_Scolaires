#include <stdio.h>
#include <stdlib.h>

int haut (char colonne[]){
    char clique_haut;
    int i;
    int j;
    while (i = 0 < sizeof(colonne)){
            scanf("%d", &clique_haut);
            if (clique_haut == "h" || "H"){
                j = j + 1;
            }
        }
            return 0;
}

