#include <stdio.h>
#include <stdlib.h>

int niveau25 (){

    char tableau_niveau_25[4][4] = {{ 5,   1,   4,  'x'},
                                    { 4,  'x',  2,   2 },
                                    { 2,   3,   2,   3 },
                                    {'x',  2,  'x',  3 }};

    printf(tableau_niveau_25);
    return 0;
}

