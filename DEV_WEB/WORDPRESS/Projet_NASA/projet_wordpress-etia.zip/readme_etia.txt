Connexion à phpMyAdmin:
utilisateur: root
mdp: (rien)

Une fois sur phpMyAdmin:
Ouvrir un nouvel onglet et copier coller ce lien pour accéder au sie:

Pour se connecter au site et y avoir accès:
Titre du site: National Aeronautics and Supinfo Administration 
id:Etia
mdp:etia_wdp2022
email:etia-anaelle.sakoa@supinfo.com

Autrement voici le lien du site:
http://localhost/projet_wordpress/wordpress/wp-admin/