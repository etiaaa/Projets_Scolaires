#include <stdio.h>
#include <stdlib.h>

int niveau15 (){

    char tableau_niveau_15[5][4] = {{'.',  9,   8,   7 },
                                    { 4,   4,   4,   6 },
                                    { 4,  'x',  4,  'x'},
                                    { 4,   4,  '.', '.'}};

    printf(tableau_niveau_15);
    return 0;
}
