insert into ROUTE (NUMERO_DE_VOL,VILLE_D_ORIGINE,VILLE_DE_DESTINATION)
values	
		("ALL 105",	"Paris",		"Berlin"),
        ("ESP 196",	"Paris",		"Madrid"),
        ("ITL 134",	"Paris",		"Romes"),
        ("ENG 181",	"Paris",		"Londres"),
        ("BLG 150",	"Paris",		"Bruxelles"),
        ("BRS 293",	"Paris",		"Rio de Janeiro"),
        ("ARG 261",	"Paris",		"Buenos Aires"),        
		("MX 231",	"Paris",		"Mexico"),
		("VNZ 240",	"Paris",		"Caracas"),
        ("SG 282",	"Paris",		"Singapour"),
        ("CI 383",	"Paris",		"Abidjan"),
		("CGN 312",	"Paris",		"Kinshassa"),
        ("SNG 324",	"Paris",		"Dakar"),
        ("ALG 382",	"Paris",		"Alger"),
		("MRC 350",	"Paris",		"Marrakech"),
        ("CHN 405",	"Paris",		"Tokyo"),
        ("JPN 402",	"Paris",		"Pékin"),
        ("AFG 413",	"Paris",		"Kaboul"),
        ("SLK 497",	"Paris",		"Colombo"),
        ("ID 410",	"Paris",		"New Deli"),
	
	
       	("ALL 153",	"Marseille",	"Berlin"),
        ("ESP 118",	"Marseille",	"Madrid"),
		("ITL 213",	"Marseille",	"Romes"),
        ("ENG 563",	"Marseille",	"Londres"),
        ("BLG 585",	"Marseille",	"Bruxelles"),
        ("BRS 468",	"Marseille",	"Rio de Janeiro"),
        ("VNZ 129",	"Marseille",	"Caracas"),
		("MX 553",	"Marseille",	"Mexico"),
		("ARG 537",	"Marseille",	"Buenos Aires"),
        ("CI 256",	"Marseille",	"Abidjan"),
        ("CGN 785",	"Marseille",	"Kinshassa"),
         
		
        ("ITL 321",	"Brest",		"Romes"),
		("BLG 536",	"Brest",		"Bruxelles"),
        ("BLG 761",	"Brest",		"Madrid"),
        ("BLG 642",	"Brest",		"Romes"),
        ("BLG 564",	"Brest",		"Berlin");
        
      