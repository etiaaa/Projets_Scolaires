#include <stdio.h>
#include <stdlib.h>

int niveau7 (){

    char tableau_niveau_7[6][4] = {{ 'x', 5,  6,  8,  9,  9},
                                   {  1,  4,  7,  8,  6,  6},
                                   {  2,  3, 'x', 1,  2,  4},
                                   { 'x', 3,  5,  7,  8,  8}};

    printf(tableau_niveau_7);
    return 0;
}
