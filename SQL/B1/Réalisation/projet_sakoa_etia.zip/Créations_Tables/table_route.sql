CREATE TABLE ROUTE (

NUMERO_DE_VOL varchar(50),
NUMERO_DE_ROUTE int not null auto_increment,
VILLE_D_ORIGINE varchar(50),
VILLE_DE_DESTINATION varchar(50),

primary key(numero_de_route)

);