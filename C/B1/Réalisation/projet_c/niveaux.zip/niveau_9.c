#include <stdio.h>
#include <stdlib.h>

int niveau9 (){

    char tableau_niveau_9[4][5] = {{ 'x', 2,  4,  5},
                                   {  3, 'x', 7,  6},
                                   {  4,  3, 'x', 6},
                                   {  8,  3,  9,  7},
                                   {  9,  3,  7,  7}};

    printf(tableau_niveau_9);
    return 0;
}

