#include <stdio.h>
#include <stdlib.h>


int gauche(char ligne[]){
    char clique_gauche;
    int i;
    while (i = 0 < sizeof(ligne)){
            scanf("%d", &clique_gauche);
            if (clique_gauche == "d" || "D"){
                i = i - 1;
        }
    }
    return 0;
}

