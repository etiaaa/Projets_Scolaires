#include <stdio.h>
#include <stdlib.h>

int niveau26 (){

    char tableau_niveau_26[6][3] = {{ 3,   2,   2,    1,    2,    3 },
                                    { 3,   2,  'x',  'x',   1,   'x'},
                                    { 2,   2,   2,    2,    2,    2 }};

    printf(tableau_niveau_26);
    return 0;
}

