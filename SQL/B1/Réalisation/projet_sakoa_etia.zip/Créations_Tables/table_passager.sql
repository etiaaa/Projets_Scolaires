CREATE TABLE PASSAGER (

NUMERO_DU_PASSAGER int not null auto_increment,
NOM varchar(50),
PRENOM varchar(50),
ADRESSE varchar(100),
PROFESSION varchar(50),
BANQUE varchar(50),

primary key(NUMERO_DU_PASSAGER)

);