 CREATE TABLE VOL (

NUMERO_DU_VOL varchar(50),
HEURE_DEPART varchar(50),
HEURE_ARRIVEE varchar(50),

primary key(NUMERO_DU_VOL)

);