#include <stdio.h>
#include <stdlib.h>

int niveau13 (){

    char tableau_niveau_13[6][5] = {{'.',  7,  6,  3,   2,   '.'},
                                    { 9,   8,  5,  4,   1,   'x'},
                                    {'.',  4,  4,  4,  '.',  '.'},
                                    {'.',  4, '.', 4,  '.',  '.'},
                                    {'.',  4,  4,  4,  '.',  '.'}};

    printf(tableau_niveau_13);
    return 0;
}
