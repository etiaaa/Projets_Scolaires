#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>
#include <stdlib.h>

int haut (char colonne[]){
    char clique_bas;
    int i;
    int j;
    while (i = 0 < sizeof(colonne)){
            scanf("%d", &clique_bas);
            if (clique_bas == "b" || "B"){
                j = j - 1;
            }
        }
            return 0;
}
