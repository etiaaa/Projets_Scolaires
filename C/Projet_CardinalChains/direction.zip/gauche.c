#include <stdio.h>
#include <stdlib.h>

int droite(char ligne[]){
    char clique_droit;
    int i;
    while (i=0 < sizeof(ligne)){
            scanf("%d", &clique_droit);
            if (clique_droit == "g" || "G"){
                i=i+1;
        }
    }
            return 0;
}


